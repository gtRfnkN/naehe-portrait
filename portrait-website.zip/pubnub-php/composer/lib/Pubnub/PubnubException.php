<?php
 
namespace Pubnub;
use \Exception;


class PubnubException extends Exception {}